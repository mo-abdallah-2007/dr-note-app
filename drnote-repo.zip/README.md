# Dr. Note
Offline study planner. The APK is built automatically by GitHub Actions (see .github/workflows/build.yml).
